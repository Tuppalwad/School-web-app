# sem7-project-phase1
Final year project phase 1 with 50% demo
